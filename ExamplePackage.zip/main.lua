--ExamplePackage ##displaybuttons button example
-- if you want help, acess displaybuttons.com

function ButtonDown()

print(formdesign.GetKey("nomedaminhachave"))
end

function ButtonUP()

    print("button UP")
end

function FormMenu()


  formdesign.setFormControl("nomedomeucontrole",formdesign.GetKey("nomedaminhachave"),"textbox",0,0,300,100)
  

  
end

function MenuOk()

formdesign.AddKeyvalue("nomedaminhachave",formdesign.getFormControl("nomedomeucontrole"))

end

function MenuCancel()


    print("menu cancel")
end